import FlowLink from './FlowLink';

const Index = () => {
  return <FlowLink />;
};

export default Index;
