import React, { useState, useEffect } from 'react';
import { 
  MapPin, AlertCircle, MessageSquare, BarChart3, Users, Menu, X, 
  CheckCircle, AlertTriangle, Info, Send, Phone, FileText, Settings, 
  Bell, Search, Filter, Download, Eye, User, ChevronRight, ChevronDown, 
  Home, Activity, Globe, Shield, Droplets, Zap, TrendingUp, Calendar, 
  Clock, Star, ThumbsUp, MessageCircle, Play, Pause, Volume2, VolumeX,
  LogIn, UserPlus, LogOut, MapIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/hooks/useAuth';
import { useRegions, useWaterSystems, useWaterAlerts, useUserReports, usePublicConsultations } from '@/hooks/useWaterData';
import { toast } from '@/hooks/use-toast';

type UserType = 'end-user' | 'community-leader' | 'manager' | 'government-official';
type Page = 'vulnerability-mapping' | 'alerts-monitoring' | 'communication' | 'governance-dashboard' | 'social-participation';

const FlowLink = () => {
  const { user, profile, loading: authLoading, signIn, signUp, signOut } = useAuth();
  const [currentPage, setCurrentPage] = useState<Page>('vulnerability-mapping');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const [selectedRegion, setSelectedRegion] = useState<any>(null);
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  
  // Auth state
  const [isAuthMode, setIsAuthMode] = useState(!user);
  const [authType, setAuthType] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [userType, setUserType] = useState<UserType>('end-user');

  // Data hooks
  const { regions, loading: regionsLoading } = useRegions();
  const { systems, loading: systemsLoading } = useWaterSystems();
  const { alerts, loading: alertsLoading } = useWaterAlerts();
  const { reports, createReport } = useUserReports(user?.id);
  const { consultations } = usePublicConsultations();

  // Show auth if not authenticated
  useEffect(() => {
    setIsAuthMode(!user);
  }, [user]);

  const userTypeConfig = {
    'end-user': {
      name: 'Residente Vulnerável',
      color: 'risk-high',
      pages: ['vulnerability-mapping', 'alerts-monitoring', 'communication', 'social-participation'] as Page[]
    },
    'community-leader': {
      name: 'Líder Comunitário',
      color: 'risk-medium',
      pages: ['vulnerability-mapping', 'alerts-monitoring', 'communication', 'governance-dashboard', 'social-participation'] as Page[]
    },
    'manager': {
      name: 'Gestor/Ativista',
      color: 'primary',
      pages: ['vulnerability-mapping', 'alerts-monitoring', 'governance-dashboard', 'social-participation', 'communication'] as Page[]
    },
    'government-official': {
      name: 'Agente Público',
      color: 'primary',
      pages: ['governance-dashboard', 'alerts-monitoring', 'vulnerability-mapping', 'social-participation', 'communication'] as Page[]
    }
  };

  const pages = {
    'vulnerability-mapping': {
      title: 'Mapeamento de Vulnerabilidade Hídrica',
      icon: MapPin,
      color: 'text-destructive'
    },
    'alerts-monitoring': {
      title: 'Monitoramento e Alertas Contínuos',
      icon: AlertCircle,
      color: 'text-warning'
    },
    'communication': {
      title: 'Comunicação Multi-nível',
      icon: MessageSquare,
      color: 'text-success'
    },
    'governance-dashboard': {
      title: 'Dashboard de Governança',
      icon: BarChart3,
      color: 'text-primary'
    },
    'social-participation': {
      title: 'Portal de Participação Social',
      icon: Users,
      color: 'text-purple-600'
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (authType === 'signin') {
        await signIn(email, password);
        toast({
          title: "Login realizado com sucesso!",
          description: "Bem-vindo ao FlowLink."
        });
      } else {
        await signUp(email, password, fullName, userType);
        toast({
          title: "Conta criada com sucesso!",
          description: "Verifique seu email para confirmar a conta."
        });
      }
    } catch (error: any) {
      toast({
        title: "Erro de autenticação",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
    } catch (error: any) {
      toast({
        title: "Erro ao sair",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const showFeedback = (message: string) => {
    toast({
      title: message,
      duration: 2000
    });
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'low': return 'risk-low';
      case 'medium': return 'risk-medium';
      case 'high': return 'risk-high';
      case 'critical': return 'risk-critical';
      default: return 'risk-medium';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'info': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'warning': return 'bg-warning/10 text-warning border-warning/20';
      case 'critical': return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'emergency': return 'bg-red-950/10 text-red-900 border-red-900/20';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-water flex items-center justify-center">
        <div className="text-center">
          <Droplets className="w-16 h-16 text-primary mx-auto mb-4 animate-water-ripple" />
          <p className="text-lg text-primary">Carregando FlowLink...</p>
        </div>
      </div>
    );
  }

  if (isAuthMode) {
    return (
      <div className="min-h-screen bg-gradient-water flex items-center justify-center p-4">
        <Card className="w-full max-w-md card-elevated">
          <CardHeader className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Droplets className="w-8 h-8 text-primary" />
              <span className="text-2xl font-bold text-gradient">FlowLink</span>
            </div>
            <CardTitle className="text-xl">
              {authType === 'signin' ? 'Entrar no Sistema' : 'Criar Conta'}
            </CardTitle>
            <p className="text-muted-foreground text-sm">
              Sistema Integrado de Governança Hídrica da RMSP
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAuth} className="space-y-4">
              {authType === 'signup' && (
                <>
                  <div>
                    <label className="text-sm font-medium">Nome Completo</label>
                    <Input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      required
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Tipo de Usuário</label>
                    <Select value={userType} onValueChange={(value: UserType) => setUserType(value)}>
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="end-user">Residente Vulnerável</SelectItem>
                        <SelectItem value="community-leader">Líder Comunitário</SelectItem>
                        <SelectItem value="manager">Gestor/Ativista</SelectItem>
                        <SelectItem value="government-official">Agente Público</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}
              
              <div>
                <label className="text-sm font-medium">Email</label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="mt-1"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium">Senha</label>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="mt-1"
                />
              </div>

              <Button type="submit" className="w-full" size="lg">
                {authType === 'signin' ? (
                  <>
                    <LogIn className="w-4 h-4 mr-2" />
                    Entrar
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4 mr-2" />
                    Criar Conta
                  </>
                )}
              </Button>

              <div className="text-center">
                <Button
                  type="button"
                  variant="link"
                  onClick={() => setAuthType(authType === 'signin' ? 'signup' : 'signin')}
                >
                  {authType === 'signin' 
                    ? 'Não tem conta? Criar uma nova' 
                    : 'Já tem conta? Fazer login'
                  }
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  const Header = () => (
    <header className="bg-card shadow-md border-b-2 border-primary/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Droplets className="w-8 h-8 text-primary" />
              <span className="text-2xl font-bold text-gradient">FlowLink</span>
            </div>
            <div className="hidden md:flex items-center space-x-2">
              <Badge className={`bg-${userTypeConfig[profile?.user_type as UserType || 'end-user'].color}/10 text-${userTypeConfig[profile?.user_type as UserType || 'end-user'].color} border-${userTypeConfig[profile?.user_type as UserType || 'end-user'].color}/20`}>
                {userTypeConfig[profile?.user_type as UserType || 'end-user'].name}
              </Badge>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setAudioEnabled(!audioEnabled)}
              title={audioEnabled ? 'Desabilitar Áudio' : 'Habilitar Áudio'}
            >
              {audioEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => showFeedback('Notificações verificadas')}
              className="relative"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-destructive rounded-full"></span>
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              title="Sair do sistema"
            >
              <LogOut className="w-5 h-5" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>
      </div>
    </header>
  );

  const Navigation = () => {
    const availablePages = userTypeConfig[profile?.user_type as UserType || 'end-user'].pages;
    
    return (
      <nav className={`bg-card shadow-sm ${isMenuOpen ? 'block' : 'hidden'} md:block`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-4 py-4">
            {availablePages.map((pageId) => {
              const page = pages[pageId];
              const IconComponent = page.icon;
              return (
                <Button
                  key={pageId}
                  variant={currentPage === pageId ? "default" : "ghost"}
                  onClick={() => {
                    setCurrentPage(pageId);
                    showFeedback(`Navegando para ${page.title}`);
                    setIsMenuOpen(false);
                  }}
                  className="justify-start"
                >
                  <IconComponent className="w-5 h-5 mr-2" />
                  <span className="text-sm">{page.title}</span>
                </Button>
              );
            })}
          </div>
        </div>
      </nav>
    );
  };

  const VulnerabilityMapping = () => (
    <div className="space-y-6">
      <Card className="card-elevated">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl text-gradient">Mapa de Vulnerabilidade Hídrica da RMSP</CardTitle>
            <div className="flex space-x-2">
              <Button onClick={() => showFeedback('Guia de áudio iniciado')}>
                <Play className="w-4 h-4 mr-2" />
                Guia de Áudio
              </Button>
              <Button variant="outline" onClick={() => showFeedback('Seção de ajuda aberta')}>
                Ajuda
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-gradient-water rounded-lg p-8 mb-6 min-h-[400px] flex flex-col items-center justify-center border border-primary/20">
            <MapIcon className="w-16 h-16 text-primary/40 mb-4" />
            <div className="text-center text-primary/80">
              <p className="text-lg font-semibold mb-2">Integração de Mapa Interativo</p>
              <p className="text-sm">
                <strong>Leaflet.js + OpenStreetMap API</strong><br />
                Recursos: Clique em regiões para detalhes de vulnerabilidade<br />
                <em>API Nominatim para geocodificação, visualização de níveis de risco em tempo real</em>
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <Button 
              onClick={() => {
                if (regions.length > 0) {
                  setSelectedRegion(regions[0]);
                  showFeedback('Verificando sua área...');
                }
              }}
              className="btn-success h-16"
            >
              <Search className="w-5 h-5 mr-2" />
              <span>Verificar Minha Área</span>
            </Button>
            <Button 
              onClick={() => showFeedback('Localizador ativado')}
              className="h-16"
            >
              <MapPin className="w-5 h-5 mr-2" />
              <span>Encontrar Localização</span>
            </Button>
          </div>

          {selectedRegion && (
            <Card className="mb-6 border-l-4 border-l-primary">
              <CardHeader>
                <CardTitle className="text-lg">Status da Sua Região</CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`p-4 rounded-lg mb-4 ${
                  selectedRegion.risk_level === 'high' || selectedRegion.risk_level === 'critical' 
                    ? 'bg-destructive/10 border border-destructive/20' :
                  selectedRegion.risk_level === 'medium' 
                    ? 'bg-warning/10 border border-warning/20' :
                    'bg-success/10 border border-success/20'
                }`}>
                  <div className="flex items-center space-x-2 mb-2">
                    <AlertTriangle className={`w-5 h-5 ${
                      selectedRegion.risk_level === 'high' || selectedRegion.risk_level === 'critical'
                        ? 'text-destructive' :
                      selectedRegion.risk_level === 'medium' 
                        ? 'text-warning' :
                        'text-success'
                    }`} />
                    <span className="font-bold uppercase">
                      RISCO {selectedRegion.risk_level}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Sua área está classificada como {selectedRegion.risk_level === 'high' ? 'alta' : selectedRegion.risk_level === 'medium' ? 'média' : 'baixa'} vulnerabilidade à escassez hídrica
                  </p>
                </div>
                <div className="text-sm space-y-1">
                  <p>• Densidade populacional: {selectedRegion.population?.toLocaleString()} pessoas</p>
                  <p>• Confiabilidade do acesso à água: {selectedRegion.reliability_percentage}%</p>
                  <p>• Índice de vulnerabilidade socioeconômica: {selectedRegion.vulnerability_index}/10</p>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button variant="destructive" onClick={() => showFeedback('Relatório de emergência iniciado')}>
              <AlertCircle className="w-5 h-5 mr-2" />
              Reportar Problema
            </Button>
            <Button variant="outline" onClick={() => showFeedback('Visualização detalhada aberta')}>
              <Eye className="w-5 h-5 mr-2" />
              Ver Detalhes
            </Button>
            <Button variant="outline" onClick={() => {
              setAudioEnabled(true);
              showFeedback('Guia de áudio iniciado');
            }}>
              <Volume2 className="w-5 h-5 mr-2" />
              Guia de Áudio
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-800 text-lg">🔧 Recursos de Acessibilidade</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Botões grandes e alto contraste para navegação fácil</li>
              <li>• Descrições em áudio para elementos do mapa</li>
              <li>• Linguagem simples e indicadores visuais claros</li>
              <li>• Interface amigável para dispositivos móveis</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-purple-50 border-purple-200">
          <CardHeader>
            <CardTitle className="text-purple-800 text-lg">⚙️ Notas de Integração Técnica</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="text-sm text-purple-700 space-y-1">
              <li>• API do Mapa: Leaflet.js com tiles do OpenStreetMap</li>
              <li>• Geocodificação: API Nominatim para serviços de localização</li>
              <li>• Atualizações em tempo real: Conexões WebSocket para dados ao vivo</li>
              <li>• Suporte offline: Service worker para conteúdo em cache</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const AlertsMonitoring = () => (
    <div className="space-y-6">
      <Card className="card-elevated">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl text-gradient">Monitoramento de Água em Tempo Real</CardTitle>
            <div className="flex space-x-2">
              <Button onClick={() => showFeedback('Configurações de alerta abertas')}>
                <Settings className="w-4 h-4 mr-2" />
                Configurar Alertas
              </Button>
              <Button variant="success" onClick={() => showFeedback('Status de áudio ativado')}>
                <Volume2 className="w-4 h-4 mr-2" />
                Ouvir Status
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Active Alerts */}
          <div className="space-y-4 mb-6">
            {alerts.slice(0, 3).map((alert) => (
              <div key={alert.id} className={`p-4 rounded-lg border ${getSeverityColor(alert.severity)}`}>
                <div className="flex items-center space-x-2 mb-2">
                  <AlertTriangle className="w-5 h-5" />
                  <span className="font-bold uppercase">{alert.severity}</span>
                </div>
                <h3 className="font-semibold mb-1">{alert.title}</h3>
                <p className="text-sm">{alert.description}</p>
              </div>
            ))}
          </div>

          {/* Water Systems Status */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {systems.slice(0, 4).map((system) => (
              <Card key={system.id} className="text-center">
                <CardContent className="pt-4">
                  <div className={`text-3xl font-bold mb-2 ${
                    system.capacity_percentage < 30 ? 'text-destructive' : 
                    system.capacity_percentage < 60 ? 'text-warning' : 
                    'text-success'
                  }`}>
                    {Math.round(system.capacity_percentage)}%
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {system.name}
                  </div>
                  <Badge variant="outline" className="mt-2">
                    {system.status === 'operational' ? 'Operacional' : 
                     system.status === 'maintenance' ? 'Manutenção' : 
                     'Emergência'}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="bg-gradient-water border border-primary/20">
            <CardHeader>
              <CardTitle className="text-primary">Tendências dos Níveis de Água - Últimos 30 Dias</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-32 flex items-center justify-center text-primary/80">
                <div className="text-center">
                  <TrendingUp className="w-12 h-12 mx-auto mb-2" />
                  <p className="font-semibold">Integração Chart.js</p>
                  <p className="text-sm">Visualização de dados em tempo real com tendências históricas</p>
                  <em className="text-xs">Conectado à API do Google Sheets para armazenamento de dados</em>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );

  const Communication = () => (
    <div className="space-y-6">
      <Card className="card-elevated">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl text-gradient">Central de Comunicação</CardTitle>
            <Button variant="success" onClick={() => showFeedback('Linha de ajuda contatada')}>
              <Phone className="w-4 h-4 mr-2" />
              Linha de Ajuda
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <Button variant="destructive" size="lg" onClick={() => showFeedback('Relatório de emergência iniciado')}>
              <AlertCircle className="w-5 h-5 mr-2" />
              Reportar Emergência
            </Button>
            <Button size="lg" onClick={() => showFeedback('Chat iniciado')}>
              <MessageCircle className="w-5 h-5 mr-2" />
              Iniciar Chat
            </Button>
          </div>

          {/* Mock Chat */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Suporte ao Vivo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-muted rounded-lg p-4 max-h-64 overflow-y-auto mb-4 space-y-3">
                <div className="bg-primary/10 rounded-lg p-3 max-w-xs ml-auto">
                  <p className="text-sm">A água foi cortada no meu prédio há 3 dias. Quando será restaurada?</p>
                </div>
                <div className="bg-card rounded-lg p-3 max-w-xs border">
                  <p className="text-sm">Obrigado por reportar. Escalamos seu caso para a Autoridade Municipal de Água. ID do caso: #WR-2024-0847</p>
                </div>
                <div className="bg-card rounded-lg p-3 max-w-xs border">
                  <p className="text-sm">Atualização: Equipe técnica enviada para sua área. Restauração esperada: 6-8 horas.</p>
                </div>
              </div>
              <div className="flex space-x-2">
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Digite sua mensagem..."
                  className="flex-1"
                />
                <Button onClick={() => {
                  if (newMessage.trim()) {
                    showFeedback('Mensagem enviada');
                    setNewMessage('');
                  }
                }}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* User Reports */}
          {reports.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Meus Relatórios</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {reports.slice(0, 3).map((report) => (
                    <div key={report.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div>
                        <p className="font-medium">{report.case_number} - {report.title}</p>
                        <p className="text-sm text-muted-foreground">
                          Reportado {new Date(report.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge className={
                        report.status === 'resolved' ? 'bg-success/10 text-success border-success/20' :
                        report.status === 'in-progress' ? 'bg-warning/10 text-warning border-warning/20' :
                        'bg-muted text-muted-foreground'
                      }>
                        {report.status === 'resolved' ? 'Resolvido' :
                         report.status === 'in-progress' ? 'Em Andamento' :
                         'Enviado'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  );

  const GovernanceDashboard = () => (
    <div className="space-y-6">
      <Card className="card-elevated">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl text-gradient">Dashboard de Governança</CardTitle>
            <div className="flex space-x-2">
              <Button onClick={() => showFeedback('Relatórios completos abertos')}>
                <BarChart3 className="w-4 h-4 mr-2" />
                Ver Relatórios Completos
              </Button>
              <Button variant="success" onClick={() => showFeedback('Ferramentas de coordenação acessadas')}>
                <Settings className="w-4 h-4 mr-2" />
                Ferramentas de Coordenação
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card className="text-center">
              <CardContent className="pt-4">
                <div className="text-3xl font-bold text-destructive mb-2">{alerts.length}</div>
                <div className="text-sm text-muted-foreground">Alertas Ativos</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-4">
                <div className="text-3xl font-bold text-warning mb-2">8</div>
                <div className="text-sm text-muted-foreground">Casos de Emergência</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-4">
                <div className="text-3xl font-bold text-primary mb-2">{reports.length}</div>
                <div className="text-sm text-muted-foreground">Relatórios Hoje</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-4">
                <div className="text-3xl font-bold text-success mb-2">94%</div>
                <div className="text-sm text-muted-foreground">Taxa de Resposta</div>
              </CardContent>
            </Card>
          </div>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Ações Prioritárias Necessárias</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <AlertTriangle className="w-5 h-5 text-destructive" />
                    <span className="font-bold text-destructive">IMEDIATO</span>
                  </div>
                  <p className="text-destructive mb-2">Aprovar distribuição emergencial de água para Zona Leste</p>
                  <Button variant="destructive" size="sm" onClick={() => showFeedback('Aprovação de emergência iniciada')}>
                    Tomar Ação
                  </Button>
                </div>
                <div className="bg-warning/10 border border-warning/20 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <AlertCircle className="w-5 h-5 text-warning" />
                    <span className="font-bold text-warning">URGENTE</span>
                  </div>
                  <p className="text-warning mb-2">Revisar alocação orçamentária para reparos de infraestrutura</p>
                  <Button variant="warning" size="sm" onClick={() => showFeedback('Revisão orçamentária iniciada')}>
                    Revisar
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-water border border-primary/20">
            <CardHeader>
              <CardTitle className="text-primary">Cronograma de Coordenação Multi-Entidades</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-32 flex items-center justify-center text-primary/80">
                <div className="text-center">
                  <Calendar className="w-12 h-12 mx-auto mb-2" />
                  <p className="font-semibold">Integração Google Data Studio</p>
                  <p className="text-sm">Cronograma de coordenação em tempo real e rastreamento de decisões</p>
                  <em className="text-xs">Conectado ao Google Sheets para registro automatizado</em>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );

  const SocialParticipation = () => (
    <div className="space-y-6">
      <Card className="card-elevated">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl text-gradient">Portal de Participação Social</CardTitle>
            <div className="flex space-x-2">
              <Button onClick={() => showFeedback('Sugestão enviada')}>
                <FileText className="w-4 h-4 mr-2" />
                Enviar Sugestão
              </Button>
              <Button variant="success" onClick={() => showFeedback('Dados de transparência acessados')}>
                <Eye className="w-4 h-4 mr-2" />
                Ver Transparência
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Active Consultations */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Consultas Públicas Ativas</CardTitle>
            </CardHeader>
            <CardContent>
              {consultations.filter(c => c.status === 'open').slice(0, 2).map((consultation) => (
                <div key={consultation.id} className="bg-warning/10 border border-warning/20 rounded-lg p-4 mb-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <MessageCircle className="w-5 h-5 text-warning" />
                    <span className="font-bold text-warning">Aberto para Comentários</span>
                  </div>
                  <p className="font-medium mb-2">{consultation.title}</p>
                  <p className="text-sm text-muted-foreground mb-3">{consultation.description}</p>
                  <Button variant="warning" size="sm" onClick={() => showFeedback('Participação na consulta iniciada')}>
                    💬 Participar
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Community Forum */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Fórum da Comunidade</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="bg-card border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">Melhorias na qualidade da água na Zona Norte</h4>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <ThumbsUp className="w-4 h-4" />
                      <span>12</span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">Postado por Maria S. - Líder Comunitário | 12 respostas</p>
                </div>
                <div className="bg-card border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">Sugestão: Caminhões de água móveis para emergências</h4>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <ThumbsUp className="w-4 h-4" />
                      <span>8</span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">Postado por João R. - Residente | 8 respostas</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Transparency Data */}
          <Card className="bg-gradient-water border border-primary/20">
            <CardHeader>
              <CardTitle className="text-primary">Monitoramento de Recursos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-32 flex items-center justify-center text-primary/80 mb-4">
                <div className="text-center">
                  <BarChart3 className="w-12 h-12 mx-auto mb-2" />
                  <p className="font-semibold">Transparência de Alocação e Gastos Orçamentários</p>
                  <em className="text-xs">Gráficos do Google Data Studio com dados orçamentários em tempo real</em>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <p>Investimentos em infraestrutura: R$ 2,3M alocados, R$ 1,8M gastos</p>
                <p>Fundo de resposta emergencial: R$ 500K alocados, R$ 320K gastos</p>
                <p>Programas comunitários: R$ 150K alocados, R$ 89K gastos</p>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'vulnerability-mapping':
        return <VulnerabilityMapping />;
      case 'alerts-monitoring':
        return <AlertsMonitoring />;
      case 'communication':
        return <Communication />;
      case 'governance-dashboard':
        return <GovernanceDashboard />;
      case 'social-participation':
        return <SocialParticipation />;
      default:
        return <VulnerabilityMapping />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderCurrentPage()}
      </main>
      
      <footer className="bg-card border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Droplets className="w-8 h-8 text-primary" />
              <span className="text-2xl font-bold text-gradient">FlowLink</span>
            </div>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-4">
              Sistema Integrado de Governança Hídrica para a Região Metropolitana de São Paulo (RMSP).
              Abordando a escassez urbana de água através de tecnologia, transparência e engajamento comunitário.
            </p>
            <div className="text-sm text-muted-foreground">
              <p>Versão Protótipo 2.0.0 | Construído com React + Tailwind CSS + Supabase</p>
              <p>Pronto para integração com APIs gratuitas e plataformas no-code</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default FlowLink;