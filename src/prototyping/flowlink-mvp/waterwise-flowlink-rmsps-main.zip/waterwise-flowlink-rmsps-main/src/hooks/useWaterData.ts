import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';

export interface Region {
  id: string;
  name: string;
  zone: string;
  population: number;
  risk_level: string;
  reliability_percentage: number;
  vulnerability_index: number;
}

export interface WaterSystem {
  id: string;
  name: string;
  system_type: string;
  capacity_percentage: number;
  status: string;
  region_id?: string;
}

export interface WaterAlert {
  id: string;
  title: string;
  description: string;
  alert_type: string;
  severity: string;
  status: string;
  start_time?: string;
  end_time?: string;
  region_id?: string;
  system_id?: string;
}

export interface UserReport {
  id: string;
  case_number: string;
  title: string;
  description: string;
  report_type: string;
  priority: string;
  status: string;
  location_details?: string;
  created_at: string;
  updated_at: string;
}

export interface PublicConsultation {
  id: string;
  title: string;
  description: string;
  consultation_type: string;
  status: string;
  start_date?: string;
  end_date?: string;
  created_at: string;
}

export type ReportInsert = {
  title: string;
  description: string;
  report_type: string;
  priority: string;
  status: string;
  location_details?: string;
};

export const useRegions = () => {
  const [regions, setRegions] = useState<Region[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchRegions = async () => {
      try {
        const { data, error } = await supabase
          .from('regions')
          .select('*')
          .order('name');
        
        if (error) throw error;
        setRegions(data || []);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchRegions();
  }, []);

  return { regions, loading, error };
};

export const useWaterSystems = () => {
  const [systems, setSystems] = useState<WaterSystem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchSystems = async () => {
      try {
        const { data, error } = await supabase
          .from('water_systems')
          .select('*')
          .order('name');
        
        if (error) throw error;
        setSystems(data || []);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchSystems();

    // Set up real-time subscription
    const channel = supabase
      .channel('water_systems_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'water_systems' },
        () => fetchSystems()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return { systems, loading, error };
};

export const useWaterAlerts = () => {
  const [alerts, setAlerts] = useState<WaterAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const { data, error } = await supabase
          .from('water_alerts')
          .select('*')
          .eq('status', 'active')
          .order('severity', { ascending: false })
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        setAlerts(data || []);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAlerts();

    // Set up real-time subscription
    const channel = supabase
      .channel('water_alerts_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'water_alerts' },
        () => fetchAlerts()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return { alerts, loading, error };
};

export const useUserReports = (userId?: string) => {
  const [reports, setReports] = useState<UserReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }

    const fetchReports = async () => {
      try {
        const { data, error } = await supabase
          .from('user_reports')
          .select('*')
          .eq('user_id', userId)
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        setReports(data || []);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchReports();

    // Set up real-time subscription
    const channel = supabase
      .channel('user_reports_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'user_reports' },
        (payload) => {
          if (payload.new && (payload.new as any).user_id === userId) {
            fetchReports();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);

  const createReport = async (report: ReportInsert) => {
    if (!userId) throw new Error('User not authenticated');
    
    try {
      const { data, error } = await supabase
        .from('user_reports')
        .insert({ ...report, user_id: userId } as any)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (err: any) {
      throw new Error(err.message);
    }
  };

  return { reports, loading, error, createReport };
};

export const usePublicConsultations = () => {
  const [consultations, setConsultations] = useState<PublicConsultation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchConsultations = async () => {
      try {
        const { data, error } = await supabase
          .from('public_consultations')
          .select('*')
          .in('status', ['open', 'closed'])
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        setConsultations(data || []);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchConsultations();
  }, []);

  return { consultations, loading, error };
};