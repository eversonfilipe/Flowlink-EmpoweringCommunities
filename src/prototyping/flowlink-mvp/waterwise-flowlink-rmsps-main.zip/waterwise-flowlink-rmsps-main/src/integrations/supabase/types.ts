export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      consultation_comments: {
        Row: {
          comment_text: string
          consultation_id: string
          created_at: string
          id: string
          is_featured: boolean | null
          parent_comment_id: string | null
          updated_at: string
          user_id: string
          votes_down: number | null
          votes_up: number | null
        }
        Insert: {
          comment_text: string
          consultation_id: string
          created_at?: string
          id?: string
          is_featured?: boolean | null
          parent_comment_id?: string | null
          updated_at?: string
          user_id: string
          votes_down?: number | null
          votes_up?: number | null
        }
        Update: {
          comment_text?: string
          consultation_id?: string
          created_at?: string
          id?: string
          is_featured?: boolean | null
          parent_comment_id?: string | null
          updated_at?: string
          user_id?: string
          votes_down?: number | null
          votes_up?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "consultation_comments_consultation_id_fkey"
            columns: ["consultation_id"]
            isOneToOne: false
            referencedRelation: "public_consultations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "consultation_comments_parent_comment_id_fkey"
            columns: ["parent_comment_id"]
            isOneToOne: false
            referencedRelation: "consultation_comments"
            referencedColumns: ["id"]
          },
        ]
      }
      governance_actions: {
        Row: {
          action_type: string
          affected_regions: Json | null
          approved_at: string | null
          approved_by: string | null
          budget_amount: number | null
          completed_at: string | null
          created_at: string
          created_by: string
          deadline: string | null
          description: string
          id: string
          priority: string
          responsible_entity: string | null
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          action_type: string
          affected_regions?: Json | null
          approved_at?: string | null
          approved_by?: string | null
          budget_amount?: number | null
          completed_at?: string | null
          created_at?: string
          created_by: string
          deadline?: string | null
          description: string
          id?: string
          priority: string
          responsible_entity?: string | null
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          action_type?: string
          affected_regions?: Json | null
          approved_at?: string | null
          approved_by?: string | null
          budget_amount?: number | null
          completed_at?: string | null
          created_at?: string
          created_by?: string
          deadline?: string | null
          description?: string
          id?: string
          priority?: string
          responsible_entity?: string | null
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      lead_activities: {
        Row: {
          activity_type: string
          created_at: string | null
          description: string | null
          id: string
          lead_id: string | null
        }
        Insert: {
          activity_type: string
          created_at?: string | null
          description?: string | null
          id?: string
          lead_id?: string | null
        }
        Update: {
          activity_type?: string
          created_at?: string | null
          description?: string | null
          id?: string
          lead_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_activities_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_enrichment: {
        Row: {
          annual_revenue: string | null
          company_size: string | null
          company_website: string | null
          created_at: string | null
          id: string
          industry: string | null
          lead_id: string | null
          linkedin_url: string | null
          technologies_used: string[] | null
          updated_at: string | null
        }
        Insert: {
          annual_revenue?: string | null
          company_size?: string | null
          company_website?: string | null
          created_at?: string | null
          id?: string
          industry?: string | null
          lead_id?: string | null
          linkedin_url?: string | null
          technologies_used?: string[] | null
          updated_at?: string | null
        }
        Update: {
          annual_revenue?: string | null
          company_size?: string | null
          company_website?: string | null
          created_at?: string | null
          id?: string
          industry?: string | null
          lead_id?: string | null
          linkedin_url?: string | null
          technologies_used?: string[] | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lead_enrichment_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_tags: {
        Row: {
          created_at: string | null
          lead_id: string
          tag_id: string
        }
        Insert: {
          created_at?: string | null
          lead_id: string
          tag_id: string
        }
        Update: {
          created_at?: string | null
          lead_id?: string
          tag_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_tags_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lead_tags_tag_id_fkey"
            columns: ["tag_id"]
            isOneToOne: false
            referencedRelation: "tags"
            referencedColumns: ["id"]
          },
        ]
      }
      leads: {
        Row: {
          city: string | null
          company: string | null
          consent_marketing: boolean | null
          created_at: string | null
          email: string
          id: string
          lead_score: number | null
          message: string | null
          name: string
          objective: string | null
          phone: string | null
          position: string | null
          source: string | null
          status: string | null
          updated_at: string | null
        }
        Insert: {
          city?: string | null
          company?: string | null
          consent_marketing?: boolean | null
          created_at?: string | null
          email: string
          id?: string
          lead_score?: number | null
          message?: string | null
          name: string
          objective?: string | null
          phone?: string | null
          position?: string | null
          source?: string | null
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          city?: string | null
          company?: string | null
          consent_marketing?: boolean | null
          created_at?: string | null
          email?: string
          id?: string
          lead_score?: number | null
          message?: string | null
          name?: string
          objective?: string | null
          phone?: string | null
          position?: string | null
          source?: string | null
          status?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      meetings: {
        Row: {
          created_at: string | null
          end_time: string
          id: string
          lead_id: string | null
          meeting_url: string | null
          notes: string | null
          start_time: string
          status: string | null
          title: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          end_time: string
          id?: string
          lead_id?: string | null
          meeting_url?: string | null
          notes?: string | null
          start_time: string
          status?: string | null
          title: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          end_time?: string
          id?: string
          lead_id?: string | null
          meeting_url?: string | null
          notes?: string | null
          start_time?: string
          status?: string | null
          title?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "meetings_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          attachments: Json | null
          created_at: string
          id: string
          is_read: boolean | null
          message_text: string
          message_type: string
          recipient_id: string | null
          report_id: string | null
          sender_id: string
        }
        Insert: {
          attachments?: Json | null
          created_at?: string
          id?: string
          is_read?: boolean | null
          message_text: string
          message_type?: string
          recipient_id?: string | null
          report_id?: string | null
          sender_id: string
        }
        Update: {
          attachments?: Json | null
          created_at?: string
          id?: string
          is_read?: boolean | null
          message_text?: string
          message_type?: string
          recipient_id?: string | null
          report_id?: string | null
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_report_id_fkey"
            columns: ["report_id"]
            isOneToOne: false
            referencedRelation: "user_reports"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          address: string | null
          created_at: string
          full_name: string
          id: string
          phone: string | null
          region_id: string | null
          updated_at: string
          user_id: string
          user_type: string
        }
        Insert: {
          address?: string | null
          created_at?: string
          full_name: string
          id?: string
          phone?: string | null
          region_id?: string | null
          updated_at?: string
          user_id: string
          user_type: string
        }
        Update: {
          address?: string | null
          created_at?: string
          full_name?: string
          id?: string
          phone?: string | null
          region_id?: string | null
          updated_at?: string
          user_id?: string
          user_type?: string
        }
        Relationships: []
      }
      public_consultations: {
        Row: {
          consultation_type: string
          created_at: string
          created_by: string
          description: string
          document_url: string | null
          end_date: string | null
          id: string
          start_date: string | null
          status: string
          summary_results: Json | null
          title: string
          updated_at: string
        }
        Insert: {
          consultation_type: string
          created_at?: string
          created_by: string
          description: string
          document_url?: string | null
          end_date?: string | null
          id?: string
          start_date?: string | null
          status?: string
          summary_results?: Json | null
          title: string
          updated_at?: string
        }
        Update: {
          consultation_type?: string
          created_at?: string
          created_by?: string
          description?: string
          document_url?: string | null
          end_date?: string | null
          id?: string
          start_date?: string | null
          status?: string
          summary_results?: Json | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      regions: {
        Row: {
          coordinates: unknown | null
          created_at: string
          geojson_data: Json | null
          id: string
          name: string
          population: number
          reliability_percentage: number | null
          risk_level: string
          updated_at: string
          vulnerability_index: number | null
          zone: string
        }
        Insert: {
          coordinates?: unknown | null
          created_at?: string
          geojson_data?: Json | null
          id?: string
          name: string
          population?: number
          reliability_percentage?: number | null
          risk_level: string
          updated_at?: string
          vulnerability_index?: number | null
          zone: string
        }
        Update: {
          coordinates?: unknown | null
          created_at?: string
          geojson_data?: Json | null
          id?: string
          name?: string
          population?: number
          reliability_percentage?: number | null
          risk_level?: string
          updated_at?: string
          vulnerability_index?: number | null
          zone?: string
        }
        Relationships: []
      }
      tags: {
        Row: {
          color: string | null
          created_at: string | null
          id: string
          name: string
        }
        Insert: {
          color?: string | null
          created_at?: string | null
          id?: string
          name: string
        }
        Update: {
          color?: string | null
          created_at?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      user_reports: {
        Row: {
          assigned_to: string | null
          attachments: Json | null
          case_number: string
          created_at: string
          description: string
          id: string
          location_details: string | null
          priority: string
          region_id: string | null
          report_type: string
          resolution_notes: string | null
          resolved_at: string | null
          status: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          assigned_to?: string | null
          attachments?: Json | null
          case_number: string
          created_at?: string
          description: string
          id?: string
          location_details?: string | null
          priority?: string
          region_id?: string | null
          report_type: string
          resolution_notes?: string | null
          resolved_at?: string | null
          status?: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          assigned_to?: string | null
          attachments?: Json | null
          case_number?: string
          created_at?: string
          description?: string
          id?: string
          location_details?: string | null
          priority?: string
          region_id?: string | null
          report_type?: string
          resolution_notes?: string | null
          resolved_at?: string | null
          status?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_reports_region_id_fkey"
            columns: ["region_id"]
            isOneToOne: false
            referencedRelation: "regions"
            referencedColumns: ["id"]
          },
        ]
      }
      water_alerts: {
        Row: {
          alert_type: string
          created_at: string
          created_by: string | null
          description: string
          end_time: string | null
          id: string
          region_id: string | null
          severity: string
          start_time: string | null
          status: string
          system_id: string | null
          title: string
          updated_at: string
        }
        Insert: {
          alert_type: string
          created_at?: string
          created_by?: string | null
          description: string
          end_time?: string | null
          id?: string
          region_id?: string | null
          severity: string
          start_time?: string | null
          status?: string
          system_id?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          alert_type?: string
          created_at?: string
          created_by?: string | null
          description?: string
          end_time?: string | null
          id?: string
          region_id?: string | null
          severity?: string
          start_time?: string | null
          status?: string
          system_id?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "water_alerts_region_id_fkey"
            columns: ["region_id"]
            isOneToOne: false
            referencedRelation: "regions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "water_alerts_system_id_fkey"
            columns: ["system_id"]
            isOneToOne: false
            referencedRelation: "water_systems"
            referencedColumns: ["id"]
          },
        ]
      }
      water_consumption: {
        Row: {
          consumption_date: string
          consumption_type: string | null
          created_at: string
          id: string
          population_served: number | null
          region_id: string
          system_id: string | null
          volume_liters: number
        }
        Insert: {
          consumption_date: string
          consumption_type?: string | null
          created_at?: string
          id?: string
          population_served?: number | null
          region_id: string
          system_id?: string | null
          volume_liters: number
        }
        Update: {
          consumption_date?: string
          consumption_type?: string | null
          created_at?: string
          id?: string
          population_served?: number | null
          region_id?: string
          system_id?: string | null
          volume_liters?: number
        }
        Relationships: [
          {
            foreignKeyName: "water_consumption_region_id_fkey"
            columns: ["region_id"]
            isOneToOne: false
            referencedRelation: "regions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "water_consumption_system_id_fkey"
            columns: ["system_id"]
            isOneToOne: false
            referencedRelation: "water_systems"
            referencedColumns: ["id"]
          },
        ]
      }
      water_systems: {
        Row: {
          capacity_percentage: number | null
          coordinates: unknown | null
          created_at: string
          id: string
          name: string
          region_id: string | null
          status: string
          system_type: string
          updated_at: string
        }
        Insert: {
          capacity_percentage?: number | null
          coordinates?: unknown | null
          created_at?: string
          id?: string
          name: string
          region_id?: string | null
          status?: string
          system_type: string
          updated_at?: string
        }
        Update: {
          capacity_percentage?: number | null
          coordinates?: unknown | null
          created_at?: string
          id?: string
          name?: string
          region_id?: string | null
          status?: string
          system_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "water_systems_region_id_fkey"
            columns: ["region_id"]
            isOneToOne: false
            referencedRelation: "regions"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      generate_case_number: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
