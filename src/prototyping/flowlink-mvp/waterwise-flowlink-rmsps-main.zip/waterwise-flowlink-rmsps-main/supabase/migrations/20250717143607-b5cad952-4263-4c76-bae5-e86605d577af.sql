-- FlowLink Water Governance System Database Schema
-- Professional-grade database for production deployment

-- Users profiles table for additional user information
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  user_type TEXT NOT NULL CHECK (user_type IN ('end-user', 'community-leader', 'manager', 'government-official')),
  region_id UUID,
  phone TEXT,
  address TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Regions table for water vulnerability mapping
CREATE TABLE IF NOT EXISTS public.regions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  zone TEXT NOT NULL,
  population INTEGER NOT NULL DEFAULT 0,
  risk_level TEXT NOT NULL CHECK (risk_level IN ('low', 'medium', 'high', 'critical')),
  reliability_percentage DECIMAL(5,2) DEFAULT 0,
  vulnerability_index DECIMAL(3,1) DEFAULT 0,
  geojson_data JSONB,
  coordinates POINT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Water systems for monitoring
CREATE TABLE IF NOT EXISTS public.water_systems (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  system_type TEXT NOT NULL CHECK (system_type IN ('reservoir', 'treatment_plant', 'distribution')),
  capacity_percentage DECIMAL(5,2) DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'operational' CHECK (status IN ('operational', 'maintenance', 'emergency', 'offline')),
  region_id UUID REFERENCES public.regions(id),
  coordinates POINT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Water alerts and notifications
CREATE TABLE IF NOT EXISTS public.water_alerts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  alert_type TEXT NOT NULL CHECK (alert_type IN ('maintenance', 'outage', 'quality', 'emergency', 'shortage')),
  severity TEXT NOT NULL CHECK (severity IN ('info', 'warning', 'critical', 'emergency')),
  region_id UUID REFERENCES public.regions(id),
  system_id UUID REFERENCES public.water_systems(id),
  start_time TIMESTAMP WITH TIME ZONE,
  end_time TIMESTAMP WITH TIME ZONE,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'resolved', 'cancelled')),
  created_by UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- User reports and complaints
CREATE TABLE IF NOT EXISTS public.user_reports (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  case_number TEXT NOT NULL UNIQUE,
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  report_type TEXT NOT NULL CHECK (report_type IN ('outage', 'quality', 'pressure', 'leak', 'emergency', 'other')),
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  status TEXT NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted', 'in-review', 'in-progress', 'resolved', 'closed')),
  region_id UUID REFERENCES public.regions(id),
  location_details TEXT,
  attachments JSONB DEFAULT '[]',
  assigned_to UUID,
  resolution_notes TEXT,
  resolved_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Communication messages
CREATE TABLE IF NOT EXISTS public.messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  report_id UUID REFERENCES public.user_reports(id),
  sender_id UUID NOT NULL,
  recipient_id UUID,
  message_text TEXT NOT NULL,
  message_type TEXT NOT NULL DEFAULT 'user' CHECK (message_type IN ('user', 'support', 'system', 'automated')),
  is_read BOOLEAN DEFAULT FALSE,
  attachments JSONB DEFAULT '[]',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Governance decisions and actions
CREATE TABLE IF NOT EXISTS public.governance_actions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  action_type TEXT NOT NULL CHECK (action_type IN ('budget_allocation', 'policy_change', 'emergency_response', 'infrastructure', 'meeting')),
  priority TEXT NOT NULL CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'in-progress', 'completed', 'rejected')),
  budget_amount DECIMAL(15,2),
  affected_regions JSONB DEFAULT '[]',
  responsible_entity TEXT,
  deadline TIMESTAMP WITH TIME ZONE,
  created_by UUID NOT NULL,
  approved_by UUID,
  approved_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Public consultations and participatory features
CREATE TABLE IF NOT EXISTS public.public_consultations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  consultation_type TEXT NOT NULL CHECK (consultation_type IN ('policy', 'budget', 'infrastructure', 'emergency', 'general')),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'open', 'closed', 'completed')),
  start_date TIMESTAMP WITH TIME ZONE,
  end_date TIMESTAMP WITH TIME ZONE,
  document_url TEXT,
  summary_results JSONB,
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Comments on public consultations
CREATE TABLE IF NOT EXISTS public.consultation_comments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  consultation_id UUID NOT NULL REFERENCES public.public_consultations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  comment_text TEXT NOT NULL,
  parent_comment_id UUID REFERENCES public.consultation_comments(id),
  votes_up INTEGER DEFAULT 0,
  votes_down INTEGER DEFAULT 0,
  is_featured BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Water consumption data for analytics
CREATE TABLE IF NOT EXISTS public.water_consumption (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  region_id UUID NOT NULL REFERENCES public.regions(id),
  system_id UUID REFERENCES public.water_systems(id),
  consumption_date DATE NOT NULL,
  volume_liters DECIMAL(15,2) NOT NULL,
  population_served INTEGER,
  consumption_type TEXT DEFAULT 'total' CHECK (consumption_type IN ('total', 'residential', 'commercial', 'industrial')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- Enable Row Level Security on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.regions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.water_systems ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.water_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.governance_actions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.public_consultations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.consultation_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.water_consumption ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view and update their own profile" ON public.profiles
  FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for regions (public read access)
CREATE POLICY "Regions are viewable by everyone" ON public.regions
  FOR SELECT USING (true);

-- RLS Policies for water systems (public read access)
CREATE POLICY "Water systems are viewable by everyone" ON public.water_systems
  FOR SELECT USING (true);

-- RLS Policies for water alerts (public read access)
CREATE POLICY "Water alerts are viewable by everyone" ON public.water_alerts
  FOR SELECT USING (true);

CREATE POLICY "Authorized users can manage alerts" ON public.water_alerts
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE user_id = auth.uid() 
      AND user_type IN ('manager', 'government-official')
    )
  );

-- RLS Policies for user reports
CREATE POLICY "Users can view their own reports" ON public.user_reports
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own reports" ON public.user_reports
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Authorized users can view all reports" ON public.user_reports
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE user_id = auth.uid() 
      AND user_type IN ('manager', 'government-official', 'community-leader')
    )
  );

-- RLS Policies for messages
CREATE POLICY "Users can view messages in their reports" ON public.messages
  FOR SELECT USING (
    auth.uid() = sender_id OR 
    auth.uid() = recipient_id OR
    EXISTS (
      SELECT 1 FROM public.user_reports 
      WHERE id = report_id AND user_id = auth.uid()
    )
  );

CREATE POLICY "Users can send messages" ON public.messages
  FOR INSERT WITH CHECK (auth.uid() = sender_id);

-- RLS Policies for governance actions
CREATE POLICY "Governance actions are viewable by all authenticated users" ON public.governance_actions
  FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authorized users can manage governance actions" ON public.governance_actions
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE user_id = auth.uid() 
      AND user_type IN ('manager', 'government-official')
    )
  );

-- RLS Policies for public consultations
CREATE POLICY "Public consultations are viewable by everyone" ON public.public_consultations
  FOR SELECT USING (true);

CREATE POLICY "Authorized users can manage consultations" ON public.public_consultations
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE user_id = auth.uid() 
      AND user_type IN ('manager', 'government-official')
    )
  );

-- RLS Policies for consultation comments
CREATE POLICY "Comments are viewable by everyone" ON public.consultation_comments
  FOR SELECT USING (true);

CREATE POLICY "Authenticated users can create comments" ON public.consultation_comments
  FOR INSERT WITH CHECK (auth.uid() IS NOT NULL AND auth.uid() = user_id);

CREATE POLICY "Users can update their own comments" ON public.consultation_comments
  FOR UPDATE USING (auth.uid() = user_id);

-- RLS Policies for water consumption (public read for transparency)
CREATE POLICY "Water consumption data is viewable by everyone" ON public.water_consumption
  FOR SELECT USING (true);

-- Create indexes for performance
CREATE INDEX idx_profiles_user_id ON public.profiles(user_id);
CREATE INDEX idx_profiles_user_type ON public.profiles(user_type);
CREATE INDEX idx_regions_risk_level ON public.regions(risk_level);
CREATE INDEX idx_water_alerts_severity ON public.water_alerts(severity);
CREATE INDEX idx_water_alerts_status ON public.water_alerts(status);
CREATE INDEX idx_user_reports_user_id ON public.user_reports(user_id);
CREATE INDEX idx_user_reports_status ON public.user_reports(status);
CREATE INDEX idx_user_reports_case_number ON public.user_reports(case_number);
CREATE INDEX idx_messages_report_id ON public.messages(report_id);
CREATE INDEX idx_governance_actions_status ON public.governance_actions(status);
CREATE INDEX idx_consultation_comments_consultation_id ON public.consultation_comments(consultation_id);
CREATE INDEX idx_water_consumption_date ON public.water_consumption(consumption_date);

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_regions_updated_at
  BEFORE UPDATE ON public.regions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_water_systems_updated_at
  BEFORE UPDATE ON public.water_systems
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_water_alerts_updated_at
  BEFORE UPDATE ON public.water_alerts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_user_reports_updated_at
  BEFORE UPDATE ON public.user_reports
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_governance_actions_updated_at
  BEFORE UPDATE ON public.governance_actions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_public_consultations_updated_at
  BEFORE UPDATE ON public.public_consultations
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_consultation_comments_updated_at
  BEFORE UPDATE ON public.consultation_comments
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Function to generate case numbers
CREATE OR REPLACE FUNCTION generate_case_number()
RETURNS TEXT AS $$
BEGIN
  RETURN 'WR-' || TO_CHAR(NOW(), 'YYYY') || '-' || LPAD(EXTRACT(DOY FROM NOW())::TEXT, 3, '0') || LPAD(EXTRACT(HOUR FROM NOW())::TEXT, 2, '0') || LPAD(EXTRACT(MINUTE FROM NOW())::TEXT, 2, '0');
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-generate case numbers
CREATE OR REPLACE FUNCTION set_case_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.case_number IS NULL THEN
    NEW.case_number := generate_case_number();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_user_reports_case_number
  BEFORE INSERT ON public.user_reports
  FOR EACH ROW
  EXECUTE FUNCTION set_case_number();