-- Populate FlowLink database with realistic sample data for RMSP

-- Insert regions with real RMSP data
INSERT INTO public.regions (name, zone, population, risk_level, reliability_percentage, vulnerability_index) VALUES
('Zona Leste', 'east', 3800000, 'high', 68.5, 7.2),
('Zona Oeste', 'west', 2900000, 'medium', 78.2, 5.8),
('Zona Norte', 'north', 2200000, 'medium', 82.1, 4.9),
('Zona Sul', 'south', 2800000, 'high', 65.3, 8.1),
('Centro', 'center', 800000, 'low', 92.4, 3.2),
('ABC Paulista', 'southeast', 2700000, 'high', 71.2, 6.8),
('Grande São Paulo Norte', 'north', 1500000, 'critical', 58.9, 9.1),
('Região Metropolitana Oeste', 'west', 1200000, 'medium', 75.6, 5.4);

-- Insert water systems
INSERT INTO public.water_systems (name, system_type, capacity_percentage, status, region_id) VALUES
('Sistema Cantareira', 'reservoir', 34.2, 'operational', (SELECT id FROM regions WHERE name = 'Zona Norte' LIMIT 1)),
('Sistema Alto Tietê', 'reservoir', 67.8, 'operational', (SELECT id FROM regions WHERE name = 'Zona Leste' LIMIT 1)),
('Sistema Guarapiranga', 'reservoir', 45.6, 'operational', (SELECT id FROM regions WHERE name = 'Zona Sul' LIMIT 1)),
('Sistema Rio Grande', 'reservoir', 78.3, 'operational', (SELECT id FROM regions WHERE name = 'ABC Paulista' LIMIT 1)),
('Sistema Rio Claro', 'reservoir', 23.1, 'maintenance', (SELECT id FROM regions WHERE name = 'Grande São Paulo Norte' LIMIT 1)),
('ETA Alto da Boa Vista', 'treatment_plant', 89.2, 'operational', (SELECT id FROM regions WHERE name = 'Centro' LIMIT 1)),
('ETA Casa Verde', 'treatment_plant', 76.4, 'operational', (SELECT id FROM regions WHERE name = 'Zona Norte' LIMIT 1)),
('Rede de Distribuição Zona Leste', 'distribution', 72.1, 'operational', (SELECT id FROM regions WHERE name = 'Zona Leste' LIMIT 1));

-- Insert active water alerts
INSERT INTO public.water_alerts (title, description, alert_type, severity, region_id, system_id, start_time, end_time, status) VALUES
('Manutenção Programada Sistema Cantareira', 'Interrupção no abastecimento para manutenção preventiva do sistema. Residências podem ficar sem água das 6h às 14h de amanhã.', 'maintenance', 'warning', 
(SELECT id FROM regions WHERE name = 'Zona Norte' LIMIT 1), 
(SELECT id FROM water_systems WHERE name = 'Sistema Cantareira' LIMIT 1), 
NOW() + INTERVAL '1 day', NOW() + INTERVAL '1 day 8 hours', 'active'),

('Vazamento Identificado Zona Leste', 'Grande vazamento identificado na Rua das Palmeiras, 1250. Equipes técnicas já foram acionadas para reparo de emergência.', 'emergency', 'critical', 
(SELECT id FROM regions WHERE name = 'Zona Leste' LIMIT 1), 
(SELECT id FROM water_systems WHERE name = 'Rede de Distribuição Zona Leste' LIMIT 1), 
NOW() - INTERVAL '2 hours', NULL, 'active'),

('Qualidade da Água - Análise Preventiva', 'Análise preventiva da qualidade da água no Sistema Guarapiranga. Resultados esperados em 24h. Água segura para consumo.', 'quality', 'info', 
(SELECT id FROM regions WHERE name = 'Zona Sul' LIMIT 1), 
(SELECT id FROM water_systems WHERE name = 'Sistema Guarapiranga' LIMIT 1), 
NOW() - INTERVAL '6 hours', NOW() + INTERVAL '18 hours', 'active'),

('Escassez Crítica - Grande São Paulo Norte', 'Nível crítico do reservatório. Racionamento de água implementado. Abastecimento alternativo sendo organizado.', 'shortage', 'emergency', 
(SELECT id FROM regions WHERE name = 'Grande São Paulo Norte' LIMIT 1), 
(SELECT id FROM water_systems WHERE name = 'Sistema Rio Claro' LIMIT 1), 
NOW() - INTERVAL '1 day', NULL, 'active');

-- Insert governance actions
INSERT INTO public.governance_actions (title, description, action_type, priority, status, budget_amount, affected_regions, responsible_entity, deadline, created_by) VALUES
('Aprovação Emergencial - Distribuição de Água por Caminhões', 'Aprovação para distribuição emergencial de água potável via caminhões-pipa para regiões em situação crítica.', 'emergency_response', 'urgent', 'pending', 2500000.00, 
'["Grande São Paulo Norte", "Zona Leste"]', 'SABESP + Defesa Civil Municipal', NOW() + INTERVAL '6 hours', 
'00000000-0000-0000-0000-000000000001'),

('Revisão Orçamentária - Infraestrutura Hídrica 2024', 'Revisão e redistribuição do orçamento para obras de infraestrutura hídrica prioritárias na RMSP.', 'budget_allocation', 'high', 'approved', 850000000.00, 
'["Zona Leste", "Zona Sul", "ABC Paulista"]', 'Secretaria de Saneamento do Estado SP', NOW() + INTERVAL '30 days', 
'00000000-0000-0000-0000-000000000001'),

('Reunião de Coordenação Inter-municipal', 'Reunião de alinhamento entre municípios da RMSP para coordenar ações de gestão hídrica integrada.', 'meeting', 'medium', 'in-progress', NULL, 
'["Zona Norte", "Centro", "ABC Paulista"]', 'Comitê da Bacia Hidrográfica do Alto Tietê', NOW() + INTERVAL '1 day', 
'00000000-0000-0000-0000-000000000001'),

('Nova Política de Uso Racional da Água', 'Implementação de nova política municipal para uso racional da água em edifícios públicos e comerciais.', 'policy_change', 'medium', 'pending', 15000000.00, 
'["Centro", "Zona Oeste"]', 'Prefeitura de São Paulo', NOW() + INTERVAL '45 days', 
'00000000-0000-0000-0000-000000000001');

-- Insert public consultations
INSERT INTO public.public_consultations (title, description, consultation_type, status, start_date, end_date, document_url, created_by) VALUES
('Nova Estação de Tratamento - Zona Sul', 'Consulta pública sobre a construção de nova estação de tratamento de água na Zona Sul. O projeto prevê aumento de 30% na capacidade de fornecimento para a região.', 'infrastructure', 'open', 
NOW() - INTERVAL '10 days', NOW() + INTERVAL '15 days', 'https://example.com/consulta-eta-sul.pdf', 
'00000000-0000-0000-0000-000000000001'),

('Orçamento Participativo - Saneamento 2025', 'Consulta para definição de prioridades do orçamento participativo destinado a obras de saneamento e abastecimento de água.', 'budget', 'open', 
NOW() - INTERVAL '5 days', NOW() + INTERVAL '20 days', 'https://example.com/orcamento-2025.pdf', 
'00000000-0000-0000-0000-000000000001'),

('Política de Tarifa Social da Água', 'Discussão sobre nova política de tarifa social para famílias de baixa renda na região metropolitana.', 'policy', 'closed', 
NOW() - INTERVAL '60 days', NOW() - INTERVAL '15 days', 'https://example.com/tarifa-social.pdf', 
'00000000-0000-0000-0000-000000000001');

-- Insert consultation comments
INSERT INTO public.consultation_comments (consultation_id, user_id, comment_text, votes_up, votes_down, is_featured) VALUES
((SELECT id FROM public_consultations WHERE title LIKE 'Nova Estação%' LIMIT 1), '00000000-0000-0000-0000-000000000002', 'Excelente iniciativa! A Zona Sul realmente precisa dessa melhoria na infraestrutura. Sugiro que seja avaliado também o impacto ambiental na represa Guarapiranga.', 12, 1, true),
((SELECT id FROM public_consultations WHERE title LIKE 'Nova Estação%' LIMIT 1), '00000000-0000-0000-0000-000000000003', 'Importante que o projeto considere sistemas de tratamento mais modernos e sustentáveis. Qual será o cronograma de implementação?', 8, 0, false),
((SELECT id FROM public_consultations WHERE title LIKE 'Orçamento%' LIMIT 1), '00000000-0000-0000-0000-000000000004', 'Prioridade deve ser dada às regiões periféricas que sofrem mais com a falta de água. Sugiro maior investimento no sistema de distribuição.', 23, 2, true),
((SELECT id FROM public_consultations WHERE title LIKE 'Orçamento%' LIMIT 1), '00000000-0000-0000-0000-000000000005', 'Concordo com o foco nas periferias, mas também precisamos modernizar sistemas antigos que geram muito desperdício.', 15, 1, false);

-- Insert water consumption data for transparency
INSERT INTO public.water_consumption (region_id, consumption_date, volume_liters, population_served, consumption_type) VALUES
-- Data for last 30 days for multiple regions
((SELECT id FROM regions WHERE name = 'Zona Leste' LIMIT 1), CURRENT_DATE - INTERVAL '1 day', 52000000, 3800000, 'total'),
((SELECT id FROM regions WHERE name = 'Zona Oeste' LIMIT 1), CURRENT_DATE - INTERVAL '1 day', 38500000, 2900000, 'total'),
((SELECT id FROM regions WHERE name = 'Zona Norte' LIMIT 1), CURRENT_DATE - INTERVAL '1 day', 29200000, 2200000, 'total'),
((SELECT id FROM regions WHERE name = 'Zona Sul' LIMIT 1), CURRENT_DATE - INTERVAL '1 day', 37100000, 2800000, 'total'),
((SELECT id FROM regions WHERE name = 'Centro' LIMIT 1), CURRENT_DATE - INTERVAL '1 day', 14200000, 800000, 'total'),

((SELECT id FROM regions WHERE name = 'Zona Leste' LIMIT 1), CURRENT_DATE - INTERVAL '2 days', 51800000, 3800000, 'total'),
((SELECT id FROM regions WHERE name = 'Zona Oeste' LIMIT 1), CURRENT_DATE - INTERVAL '2 days', 38200000, 2900000, 'total'),
((SELECT id FROM regions WHERE name = 'Zona Norte' LIMIT 1), CURRENT_DATE - INTERVAL '2 days', 28900000, 2200000, 'total'),
((SELECT id FROM regions WHERE name = 'Zona Sul' LIMIT 1), CURRENT_DATE - INTERVAL '2 days', 36800000, 2800000, 'total'),
((SELECT id FROM regions WHERE name = 'Centro' LIMIT 1), CURRENT_DATE - INTERVAL '2 days', 14000000, 800000, 'total'),

((SELECT id FROM regions WHERE name = 'Zona Leste' LIMIT 1), CURRENT_DATE - INTERVAL '7 days', 53200000, 3800000, 'total'),
((SELECT id FROM regions WHERE name = 'Zona Oeste' LIMIT 1), CURRENT_DATE - INTERVAL '7 days', 39100000, 2900000, 'total'),
((SELECT id FROM regions WHERE name = 'Zona Norte' LIMIT 1), CURRENT_DATE - INTERVAL '7 days', 30100000, 2200000, 'total'),
((SELECT id FROM regions WHERE name = 'Zona Sul' LIMIT 1), CURRENT_DATE - INTERVAL '7 days', 38200000, 2800000, 'total'),
((SELECT id FROM regions WHERE name = 'Centro' LIMIT 1), CURRENT_DATE - INTERVAL '7 days', 14800000, 800000, 'total');